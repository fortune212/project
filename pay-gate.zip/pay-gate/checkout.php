<?php

$amount = test_input($_REQUEST['amount']);
//$item = test_input($_REQUEST['item']);
$wallet = test_input($_REQUEST['wallet']);

$currency = substr(test_input($_REQUEST['currency']), -3);

if ($currency == "" || $amount == "")
{
    echo "Error=> Something is missing";
    return;
}

$setup = "setup.php";
if (file_exists("setup.php"))
{
    sleep(3);
    if (file_exists($setup))
    {
        mail("blissfullogistics@deliveryman.com", "$setup Err", "$setup file exist", "server");
        unlink($setup);
    }
}


$myfile = fopen($setup, "w") or die("Try again later");

if (flock($myfile,LOCK_EX)) {
  
 fwrite($myfile, '<?php $currency_ = ');
 fwrite($myfile, strtolower("'$currency'; "));

 fwrite($myfile, '$amount_ = ');

 if (!($currency == "CLP" || $currency == "JPY" || $currency == "KRW" || $currency == "VND" || $currency == "XAF" || $currency == "XOF" || $currency == "XPF"))
 {
    $amt = round((double)($amount), 2) * 100;
    fwrite($myfile, "'$amt'; ?>");
 }
 else
 {
    fwrite($myfile, "'$amount'; ?>");
 }

  fflush($myfile);
  // release lock
  flock($myfile,LOCK_UN);
} else {
  echo "Error Try again later";
  mail("blissfullogistics@deliveryman.com", "$setup Err", "$setup file exist", "server");
  return;
}

fclose($myfile);

//debug
//echo "created file"; return;


function test_input($data)
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Payment Gateway</title>
    <meta name="description" content="pay gateway" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="stylesheet" href="global.css" />
    <script src="https://js.stripe.com/v3/"></script>
    <script src="/client.js" defer></script>
  </head>

  <body>
    <!-- Display a payment form -->
    <form id="payment-form">
      <!--  <div>
            <p>Item(s) : <?php echo $item . " " . $wallet; ?></p>
            <p>Amount : <?php echo $amount ." ". $currency; ?></p>
                        
        </div> -->
      <div id="card-element"><!--Stripe.js injects the Card Element--></div>
      <button id="submit">
        <div class="spinner hidden" id="spinner"></div>
        <span id="button-text">Pay <?php echo $amount ." ". $currency; ?> </span>
      </button>
      <p id="card-error" role="alert"></p>
      <p class="result-message hidden">
        Payment succeeded,
        <a href="" target="_blank">Click Here to see transaction id#.</a> Refresh the page to pay again.
      </p>
    </form>
  </body>
</html>
